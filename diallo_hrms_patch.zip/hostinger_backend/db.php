<?php
// Set official application timezone strictly to Indian Standard Time (IST / UTC+05:30)
date_default_timezone_set('Asia/Kolkata');

// ==============================================================================
// DIALLO HRMS — CENTRAL DATABASE CONNECTION & API HELPERS
// Hostinger MySQL 8.0+ / PDO Connection
// Strictly 100% Hostinger Backend (Pure PHP/MySQL — Zero Firebase dependencies)
// ==============================================================================

// Enable CORS with safe explicit origin allowlist (eliminating wildcard + credentials incompatibility)
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowedOrigins = [
    'https://hrmstfw.com',
    'http://hrmstfw.com',
    'https://www.hrmstfw.com',
    'http://localhost',
    'http://127.0.0.1',
    'http://localhost:3000',
    'http://localhost:5500',
    'http://localhost:8080'
];

if (!empty($origin)) {
    $parsedHost = parse_url($origin, PHP_URL_HOST);
    if (in_array($origin, $allowedOrigins) || $parsedHost === 'hrmstfw.com' || $parsedHost === 'www.hrmstfw.com' || $parsedHost === 'localhost' || $parsedHost === '127.0.0.1') {
        header("Access-Control-Allow-Origin: $origin");
        header("Access-Control-Allow-Credentials: true");
    } else {
        header("Access-Control-Allow-Origin: https://hrmstfw.com");
        header("Access-Control-Allow-Credentials: true");
    }
} else {
    header("Access-Control-Allow-Origin: https://hrmstfw.com");
}
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-CSRF-Token");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Ensure JSON response header by default
header("Content-Type: application/json; charset=UTF-8");

// Start secure server-side session
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_samesite', 'Lax');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        ini_set('session.cookie_secure', '1');
    }
    session_start();
}

// Try to load DB credentials from environment or .env file if available
$envLocations = [__DIR__ . '/../.env', __DIR__ . '/.env', $_SERVER['DOCUMENT_ROOT'] . '/.env'];
foreach ($envLocations as $envFile) {
    if (file_exists($envFile)) {
        $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (strpos(trim($line), '#') === 0) continue;
            if (strpos($line, '=') !== false) {
                list($key, $val) = explode('=', $line, 2);
                $key = trim($key);
                $val = trim(trim($val), '"\'');
                if (!getenv($key)) putenv("$key=$val");
            }
        }
        break;
    }
}

// Hostinger Database Configuration
$dbHost = '127.0.0.1';
$dbName = 'u147377699_HRMS';
$dbUser = 'u147377699_HRMSQL';
$dbPass = getenv('DB_PASS') ?: 'Diallo@2026';
$charset = 'utf8mb4';

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => true,
    PDO::ATTR_TIMEOUT            => 5
];

$pdo = null;
$lastError = '';

// Attempt connection: First via 127.0.0.1:3306, then localhost with verified user u147377699_HRMSQL
$hostsToTry = ['127.0.0.1', 'localhost'];
$usersToTry = ['u147377699_HRMSQL'];

foreach ($hostsToTry as $hostCandidate) {
    foreach ($usersToTry as $userCandidate) {
        try {
            $dsn = "mysql:host=$hostCandidate;port=3306;dbname=$dbName;charset=$charset";
            $pdo = new PDO($dsn, $userCandidate, $dbPass, $options);
            $pdo->exec("SET time_zone = '+05:30'");
            $dbUser = $userCandidate;
            break 2;
        } catch (\PDOException $ex) {
            $lastError = $ex->getMessage();
        }
    }
}

if (!$pdo) {
    error_log("[DB Error] Connection failed: " . $lastError);
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "error" => "Database connection error: " . $lastError,
        "details" => [
            "database" => $dbName,
            "user" => $dbUser,
            "tested_hosts" => $hostsToTry,
            "tip" => "Check database password and user privileges in Hostinger hPanel -> Databases -> MySQL Management."
        ]
    ]);
    exit();
}

// Auto-heal missing security tables on Hostinger MySQL
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `auth_tokens` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `token` VARCHAR(128) UNIQUE NOT NULL,
            `user_id` INT NOT NULL,
            `user_uid` VARCHAR(128) DEFAULT NULL,
            `user_email` VARCHAR(120) NOT NULL,
            `role_id` VARCHAR(50) NOT NULL,
            `ip_address` VARCHAR(45) DEFAULT NULL,
            `user_agent` TEXT DEFAULT NULL,
            `expires_at` DATETIME NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_token_lookup` (`token`),
            INDEX `idx_token_user` (`user_id`),
            INDEX `idx_token_expires` (`expires_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `password_resets` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `email` VARCHAR(120) NOT NULL,
            `token` VARCHAR(128) UNIQUE NOT NULL,
            `expires_at` DATETIME NOT NULL,
            `used` TINYINT(1) NOT NULL DEFAULT 0,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_pwd_reset_token` (`token`),
            INDEX `idx_pwd_reset_email` (`email`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `teams` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `department_id` INT DEFAULT NULL,
            `department_name` VARCHAR(100) DEFAULT 'Sales',
            `name` VARCHAR(120) NOT NULL,
            `code` VARCHAR(50) UNIQUE NOT NULL,
            `lead_employee_id` VARCHAR(128) DEFAULT NULL,
            `lead_name` VARCHAR(150) DEFAULT NULL,
            `description` TEXT DEFAULT NULL,
            `status` ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_team_dept` (`department_name`),
            INDEX `idx_team_lead` (`lead_employee_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `documents` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `company_id` VARCHAR(100) NOT NULL DEFAULT 'comp_diallo_india',
            `employee_id` VARCHAR(128) NOT NULL,
            `employee_code` VARCHAR(50) DEFAULT NULL,
            `title` VARCHAR(200) NOT NULL,
            `category` VARCHAR(80) NOT NULL DEFAULT 'GENERAL',
            `file_name` VARCHAR(255) NOT NULL,
            `file_path` TEXT NOT NULL,
            `file_url` TEXT DEFAULT NULL,
            `file_size` INT DEFAULT 0,
            `file_type` VARCHAR(100) DEFAULT NULL,
            `uploaded_by` VARCHAR(128) DEFAULT NULL,
            `status` ENUM('ACTIVE', 'ARCHIVED') NOT NULL DEFAULT 'ACTIVE',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_doc_emp` (`employee_id`),
            INDEX `idx_doc_cat` (`category`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // Seamless auto-migration: Ensure company_id and file_url exist if table was previously created
    try {
        $chkCol = $pdo->query("SHOW COLUMNS FROM documents LIKE 'company_id'")->fetch();
        if (!$chkCol) {
            $pdo->exec("ALTER TABLE documents ADD COLUMN company_id VARCHAR(100) DEFAULT 'comp_diallo_india' AFTER id");
        }
    } catch (\Throwable $e) {}
    try {
        $chkCol2 = $pdo->query("SHOW COLUMNS FROM documents LIKE 'file_url'")->fetch();
        if (!$chkCol2) {
            $pdo->exec("ALTER TABLE documents ADD COLUMN file_url TEXT AFTER file_path");
        }
    } catch (\Throwable $e) {}

    // Auto-normalize mismatched employee_id in attendance_records
    try {
        $pdo->exec("
            UPDATE attendance_records a
            JOIN employees e ON (a.employee_code = e.employee_code AND a.employee_code != '')
            SET a.employee_id = e.id
            WHERE a.employee_id != e.id
        ");

        // Universal Auto-fix for skewed gross_minutes across attendance_records
        $pdo->exec("
            UPDATE attendance_records 
            SET gross_minutes = TIMESTAMPDIFF(MINUTE, STR_TO_DATE(CONCAT(date, ' ', check_in), '%Y-%m-%d %h:%i %p'), STR_TO_DATE(CONCAT(date, ' ', check_out), '%Y-%m-%d %h:%i %p')),
                gross_hours_formatted = CONCAT(
                    FLOOR(TIMESTAMPDIFF(MINUTE, STR_TO_DATE(CONCAT(date, ' ', check_in), '%Y-%m-%d %h:%i %p'), STR_TO_DATE(CONCAT(date, ' ', check_out), '%Y-%m-%d %h:%i %p')) / 60),
                    'h ',
                    LPAD(MOD(TIMESTAMPDIFF(MINUTE, STR_TO_DATE(CONCAT(date, ' ', check_in), '%Y-%m-%d %h:%i %p'), STR_TO_DATE(CONCAT(date, ' ', check_out), '%Y-%m-%d %h:%i %p')), 60), 2, '0'),
                    'm'
                )
            WHERE check_in IS NOT NULL AND check_out IS NOT NULL 
              AND check_in != '' AND check_out != ''
              AND check_in LIKE '%:%M' AND check_out LIKE '%:%M'
              AND STR_TO_DATE(CONCAT(date, ' ', check_out), '%Y-%m-%d %h:%i %p') >= STR_TO_DATE(CONCAT(date, ' ', check_in), '%Y-%m-%d %h:%i %p')
              AND ABS(gross_minutes - TIMESTAMPDIFF(MINUTE, STR_TO_DATE(CONCAT(date, ' ', check_in), '%Y-%m-%d %h:%i %p'), STR_TO_DATE(CONCAT(date, ' ', check_out), '%Y-%m-%d %h:%i %p'))) > 10;
        ");

        // Auto-clean legacy duplicate employee entries in MySQL
        $pdo->exec("
            DELETE FROM employees WHERE id = 'emp_emp0001' AND EXISTS (SELECT 1 FROM users WHERE uid = 'super_admin_ayan');
            DELETE FROM employees WHERE id = 'Q7DWXwGStNNies9E6HSF' AND EXISTS (SELECT 1 FROM employees WHERE id = 'ehyJCFxLSVZwaDqNo3SWAs5UwJt2');
            DELETE FROM users WHERE uid = 'Q7DWXwGStNNies9E6HSF' AND EXISTS (SELECT 1 FROM employees WHERE id = 'ehyJCFxLSVZwaDqNo3SWAs5UwJt2');
        ");

        // Auto-populate employees table from users table if any user is missing from employees
        try {
            $pdo->exec("
                INSERT INTO employees (
                    id, user_id, employee_code, first_name, last_name, full_name,
                    email, work_email, phone, role_id, department, designation,
                    company_id, company_name, branch_name, employment_status, status, initial_password
                )
                SELECT 
                    u.uid, u.uid, COALESCE(NULLIF(u.employee_code, ''), CONCAT('D', LPAD(u.id, 5, '0'))),
                    COALESCE(NULLIF(u.first_name, ''), SUBSTRING_INDEX(u.display_name, ' ', 1)),
                    COALESCE(NULLIF(u.last_name, ''), SUBSTRING(u.display_name, LENGTH(SUBSTRING_INDEX(u.display_name, ' ', 1)) + 2)),
                    COALESCE(NULLIF(u.display_name, ''), CONCAT(COALESCE(u.first_name, ''), ' ', COALESCE(u.last_name, ''))),
                    u.email, u.email, u.phone, u.role_id,
                    COALESCE(NULLIF(u.department, ''), 'Operations'),
                    COALESCE(NULLIF(u.designation, ''), 'Associate'),
                    'comp_diallo_india', 'Diallo India Private Limited', 'HQ - Mumbai',
                    'ACTIVE', 'ACTIVE', COALESCE(u.initial_password, u.password_hash)
                FROM users u
                WHERE NOT EXISTS (
                    SELECT 1 FROM employees e 
                    WHERE e.id = u.uid 
                       OR e.user_id = u.uid 
                       OR (e.employee_code = u.employee_code AND u.employee_code IS NOT NULL AND u.employee_code != '')
                       OR (LOWER(e.email) = LOWER(u.email) AND u.email IS NOT NULL AND u.email != '')
                );
            ");
        } catch (\Throwable $e) {}

        // Auto-resolve employee_name and department in attendance_records from employees master
        try {
            $pdo->exec("
                UPDATE attendance_records a
                JOIN employees e ON (
                    a.employee_id = e.id 
                    OR a.employee_code = e.employee_code 
                    OR REPLACE(a.employee_code, '-', '') = REPLACE(e.employee_code, '-', '')
                    OR a.record_key LIKE CONCAT(e.employee_code, '_%')
                )
                SET a.employee_name = e.full_name,
                    a.employee_code = COALESCE(NULLIF(a.employee_code, ''), e.employee_code),
                    a.department = CASE WHEN a.department IS NULL OR a.department = '' OR a.department = 'Operations' OR a.department = 'General' THEN e.department ELSE a.department END
                WHERE (a.employee_name = 'Employee' OR a.employee_name IS NULL OR a.employee_name = '' OR a.employee_name = 'Staff')
                  AND e.full_name IS NOT NULL AND e.full_name != '';
            ");
        } catch (\Throwable $e) {}

        // Auto-resolve employee_name in attendance_records from users table
        try {
            $pdo->exec("
                UPDATE attendance_records a
                JOIN users u ON (
                    a.employee_id = u.uid
                    OR a.employee_id = CAST(u.id AS CHAR)
                    OR a.employee_code = u.employee_code 
                    OR REPLACE(a.employee_code, '-', '') = REPLACE(u.employee_code, '-', '')
                    OR a.record_key LIKE CONCAT(u.employee_code, '_%')
                )
                SET a.employee_name = COALESCE(NULLIF(u.display_name, ''), CONCAT(TRIM(COALESCE(u.first_name, '')), ' ', TRIM(COALESCE(u.last_name, '')))),
                    a.employee_code = COALESCE(NULLIF(a.employee_code, ''), u.employee_code),
                    a.department = CASE WHEN a.department IS NULL OR a.department = '' OR a.department = 'Operations' OR a.department = 'General' THEN COALESCE(u.department, a.department) ELSE a.department END
                WHERE (a.employee_name = 'Employee' OR a.employee_name IS NULL OR a.employee_name = '' OR a.employee_name = 'Staff');
            ");
        } catch (\Throwable $e) {}

        // Auto-clean duplicate attendance entries for same employee and date (preserves most recent)
        $pdo->exec("
            DELETE a1 FROM attendance_records a1
            INNER JOIN attendance_records a2 
            WHERE a1.id < a2.id 
              AND a1.date = a2.date 
              AND (
                (a1.employee_code = a2.employee_code AND a1.employee_code != '')
                OR a1.employee_id = a2.employee_id
                OR (a1.record_key IS NOT NULL AND a1.record_key != '' AND a1.record_key = a2.record_key)
              );
        ");

        // Auto-link reporting hierarchy (Manager and Team Lead) in employees master
        $pdo->exec("
            UPDATE employees e
            JOIN employees m ON (LOWER(TRIM(e.manager)) = LOWER(TRIM(m.full_name)) AND e.manager != '')
            SET e.manager_id = m.id
            WHERE (e.manager_id IS NULL OR e.manager_id = '');

            UPDATE employees e
            JOIN employees m ON (UPPER(TRIM(e.manager)) = UPPER(TRIM(m.employee_code)) AND e.manager != '')
            SET e.manager_id = m.id, e.manager = m.full_name
            WHERE (e.manager_id IS NULL OR e.manager_id = '');

            UPDATE employees e
            JOIN employees tl ON (LOWER(TRIM(e.team_lead)) = LOWER(TRIM(tl.full_name)) AND e.team_lead != '')
            SET e.team_lead_id = tl.id
            WHERE (e.team_lead_id IS NULL OR e.team_lead_id = '');

            UPDATE employees e
            JOIN employees tl ON (UPPER(TRIM(e.team_lead)) = UPPER(TRIM(tl.employee_code)) AND e.team_lead != '')
            SET e.team_lead_id = tl.id, e.team_lead = tl.full_name
            WHERE (e.team_lead_id IS NULL OR e.team_lead_id = '');
        ");

        // Auto-provision any missing user accounts in users table from employees master
        $pdo->exec("
            INSERT IGNORE INTO users (uid, employee_code, email, display_name, first_name, last_name, phone, role_id, department, designation, branch_name, status, password_hash)
            SELECT 
                COALESCE(NULLIF(e.user_id, ''), CONCAT('usr_', LOWER(REPLACE(e.employee_code, '-', '')))),
                e.employee_code,
                COALESCE(NULLIF(e.work_email, ''), NULLIF(e.email, ''), CONCAT(LOWER(REPLACE(e.employee_code, '-', '')), '@tradeforwealth.co.in')),
                e.full_name,
                e.first_name,
                e.last_name,
                e.phone,
                e.role_id,
                e.department,
                e.designation,
                e.branch_name,
                'ACTIVE',
                '$2y$10\$wZk0oZ7u5Zc9WfIu8U3G8uL8G5P1lK2pQ0Z9Y8X7V6U5T4S3R2Q1P'
            FROM employees e
            WHERE NOT EXISTS (
                SELECT 1 FROM users u 
                WHERE LOWER(TRIM(u.email)) = LOWER(TRIM(COALESCE(e.work_email, e.email, '')))
                   OR (u.employee_code = e.employee_code AND e.employee_code != '')
                   OR u.uid = e.user_id
            );
        ");

        // Ensure role_id columns accommodate all canonical 7 roles safely
        try {
            $pdo->exec("ALTER TABLE users MODIFY COLUMN role_id VARCHAR(50) NOT NULL DEFAULT 'EMPLOYEE'");
            $pdo->exec("ALTER TABLE employees MODIFY COLUMN role_id VARCHAR(50) NOT NULL DEFAULT 'EMPLOYEE'");
            $pdo->exec("ALTER TABLE users ADD COLUMN initial_password VARCHAR(255) DEFAULT NULL AFTER password_hash");
            $pdo->exec("ALTER TABLE employees ADD COLUMN initial_password VARCHAR(255) DEFAULT NULL");
        } catch (\Throwable $e) {}

        // Populate initial_password from password_hash if password_hash holds plaintext
        try {
            $pdo->exec("
                UPDATE users 
                SET initial_password = password_hash 
                WHERE (initial_password IS NULL OR initial_password = '') 
                  AND password_hash IS NOT NULL 
                  AND password_hash != ''
                  AND password_hash NOT LIKE '$2y$%' 
                  AND password_hash NOT LIKE '$2a$%' 
                  AND password_hash NOT LIKE '$2b$%'
                  AND password_hash NOT LIKE '$argon2%'
            ");
        } catch (\Throwable $e) {}

        // Auto Punch-Out Sweep: Closes forgotten shifts at 9:00 PM and marks as HALF_DAY
        $nowDate = date('Y-m-d');
        $nowHourMin = date('H:i');
        $pdo->prepare("
            UPDATE attendance_records
            SET check_out = '09:00 PM',
                check_out_iso = CONCAT(date, ' 21:00:00'),
                status = 'HALF_DAY',
                is_on_break = 0,
                device = CASE 
                    WHEN device IS NULL OR device = '' THEN 'Auto Punched Out (9:00 PM System)'
                    WHEN device NOT LIKE '%Auto Punched Out%' THEN CONCAT(device, ' | Auto Punched Out (9:00 PM System)')
                    ELSE device
                END,
                gross_minutes = GREATEST(0, TIMESTAMPDIFF(MINUTE, STR_TO_DATE(CONCAT(date, ' ', check_in), '%Y-%m-%d %h:%i %p'), STR_TO_DATE(CONCAT(date, ' 09:00 PM'), '%Y-%m-%d %h:%i %p'))),
                gross_hours_formatted = CONCAT(
                    FLOOR(GREATEST(0, TIMESTAMPDIFF(MINUTE, STR_TO_DATE(CONCAT(date, ' ', check_in), '%Y-%m-%d %h:%i %p'), STR_TO_DATE(CONCAT(date, ' 09:00 PM'), '%Y-%m-%d %h:%i %p'))) / 60),
                    'h ',
                    LPAD(MOD(GREATEST(0, TIMESTAMPDIFF(MINUTE, STR_TO_DATE(CONCAT(date, ' ', check_in), '%Y-%m-%d %h:%i %p'), STR_TO_DATE(CONCAT(date, ' 09:00 PM'), '%Y-%m-%d %h:%i %p'))), 60), 2, '0'),
                    'm'
                ),
                updated_at = CURRENT_TIMESTAMP
            WHERE check_in IS NOT NULL AND check_in != ''
              AND (check_out IS NULL OR check_out = '' OR check_out = '-')
              AND (
                  date < :today
                  OR (date = :today AND :now_time >= '21:00')
              )
        ")->execute([':today' => $nowDate, ':now_time' => $nowHourMin]);
    } catch (\Throwable $e) {}
} catch (\Throwable $patchErr) {
    // Non-fatal
}

/**
 * Standardized JSON response helper
 */
function json_out($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}

/**
 * Get parsed JSON input body
 */
function get_json_input() {
    $raw = file_get_contents('php://input');
    if (empty($raw)) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/**
 * Audit log helper
 */
function log_audit($pdo, $actor_id, $actor_email, $action, $resource_type, $resource_id, $meta = []) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO audit_logs (operation_id, actor_user_id, actor_email, action, resource_type, resource_id, metadata_json, user_agent, ip_address)
            VALUES (:op, :aid, :aemail, :action, :rtype, :rid, :meta, :ua, :ip)
        ");
        $stmt->execute([
            ':op' => 'OP_' . bin2hex(random_bytes(6)),
            ':aid' => $actor_id ?: 'system',
            ':aemail' => $actor_email ?: 'system',
            ':action' => $action,
            ':rtype' => $resource_type,
            ':rid' => (string)$resource_id,
            ':meta' => json_encode($meta),
            ':ua' => substr($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown', 0, 255),
            ':ip' => $_SERVER['REMOTE_ADDR'] ?? 'Unknown'
        ]);
    } catch (\Throwable $e) {
        // Non-blocking audit failure
    }
}

/**
 * Canonical Role Normalization (Strict 7 Roles: ADMIN, HR, OPS, COMPLIANCE, MANAGER, TL, EMPLOYEE)
 */
if (!function_exists('canonical_role')) {
    function canonical_role($r) {
        $clean = strtoupper(trim($r ?? 'EMPLOYEE'));
        $map = [
            'SUPER_ADMIN' => 'ADMIN',
            'COMPANY_ADMIN' => 'ADMIN',
            'ADMIN' => 'ADMIN',
            'HR_MANAGER' => 'HR',
            'HR' => 'HR',
            'OPERATIONS_MANAGER' => 'OPS',
            'PROCESS_OWNER' => 'OPS',
            'OPS' => 'OPS',
            'COMPLIANCE' => 'COMPLIANCE',
            'COMPLIANCE_OFFICER' => 'COMPLIANCE',
            'MANAGER' => 'MANAGER',
            'DEPARTMENT_MANAGER' => 'MANAGER',
            'TEAM_LEAD' => 'TL',
            'TL' => 'TL',
            'EMPLOYEE' => 'EMPLOYEE',
            'RELATIONSHIP_MANAGER' => 'EMPLOYEE',
            'DIGITAL_MARKETING' => 'EMPLOYEE',
            'MENTOR_TRAINER' => 'EMPLOYEE',
            'TRAINER' => 'EMPLOYEE',
            'TRAINEE' => 'EMPLOYEE',
            'SALES' => 'EMPLOYEE'
        ];
        return $map[$clean] ?? 'EMPLOYEE';
    }
}

/**
 * Extract Bearer Auth Token from HTTP headers or query parameter (for direct file downloads)
 */
function get_bearer_token() {
    if (!empty($_GET['token'])) return trim($_GET['token']);
    if (!empty($_GET['auth_token'])) return trim($_GET['auth_token']);

    $headers = null;
    if (isset($_SERVER['Authorization'])) {
        $headers = trim($_SERVER["Authorization"]);
    } else if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
    } elseif (function_exists('apache_request_headers')) {
        $requestHeaders = apache_request_headers();
        $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
        if (isset($requestHeaders['Authorization'])) {
            $headers = trim($requestHeaders['Authorization']);
        }
    }
    if (!empty($headers) && preg_match('/Bearer\s(\S+)/i', $headers, $matches)) {
        return $matches[1];
    }
    return null;
}

/**
 * Get current authenticated user or return null
 */
function get_current_user_or_null($pdo) {
    if (!$pdo) return null;

    $token = get_bearer_token();
    $userId = null;

    if (!empty($token)) {
        try {
            $stmt = $pdo->prepare("SELECT user_id, expires_at FROM auth_tokens WHERE token = :t LIMIT 1");
            $stmt->execute([':t' => $token]);
            $row = $stmt->fetch();
            if ($row && strtotime($row['expires_at']) > time()) {
                $userId = $row['user_id'];
            }
        } catch (\Throwable $e) {}
    }

    if (!$userId && !empty($_SESSION['user']['id'])) {
        $userId = $_SESSION['user']['id'];
    }

    if (!$userId) return null;

    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $userId]);
        $user = $stmt->fetch();
        if (!$user || ($user['status'] ?? '') === 'SUSPENDED') {
            return null;
        }

        // Hydrate employee profile
        $empStmt = $pdo->prepare("
            SELECT id as emp_id, employee_code, department, team_id, team_name, designation, role_id, manager_id, manager, team_lead_id, team_lead 
            FROM employees 
            WHERE user_id = :uid 
               OR id = :uid 
               OR LOWER(TRIM(email)) = :email 
               OR LOWER(TRIM(work_email)) = :email
               OR (employee_code = :code AND :code != '')
               OR (REPLACE(employee_code, '-', '') = :cleancode AND :cleancode != '')
            LIMIT 1
        ");
        $empStmt->execute([
            ':uid' => $user['uid'] ?: $user['id'],
            ':email' => strtolower(trim($user['email'])),
            ':code' => $user['employee_code'] ?? '',
            ':cleancode' => str_replace('-', '', $user['employee_code'] ?? '')
        ]);
        $emp = $empStmt->fetch();

        $canonical = canonical_role($emp['role_id'] ?? $user['role_id'] ?? 'EMPLOYEE');
        $user['role_id'] = $canonical;
        $user['employee_id'] = $emp['emp_id'] ?? ($user['uid'] ?: $user['id']);
        $user['employee_code'] = $emp['employee_code'] ?? ($user['employee_code'] ?? '');
        $user['department'] = $emp['department'] ?? ($user['department'] ?? 'Operations');
        $user['team_id'] = $emp['team_id'] ?? null;
        $user['team_name'] = $emp['team_name'] ?? null;
        $user['team_lead_id'] = $emp['team_lead_id'] ?? null;
        $user['manager_id'] = $emp['manager_id'] ?? null;
        $user['designation'] = $emp['designation'] ?? ($user['designation'] ?? 'Associate');

        unset($user['password_hash']);
        return $user;
    } catch (\Throwable $e) {
        return null;
    }
}

/**
 * Require valid authenticated user or terminate with 401 Unauthorized
 */
function require_authenticated_user($pdo) {
    $user = get_current_user_or_null($pdo);
    if (!$user) {
        json_out([
            "success" => false,
            "error" => "Authentication required. Please sign in.",
            "code" => "UNAUTHENTICATED"
        ], 401);
    }
    return $user;
}

/**
 * Enforce strict role authorization or terminate with 403 Forbidden
 */
function require_role($pdo, $allowedRoles = []) {
    $user = require_authenticated_user($pdo);
    $role = canonical_role($user['role_id'] ?? 'EMPLOYEE');

    // System ADMIN has universal override
    if ($role === 'ADMIN') {
        return $user;
    }

    $normalizedAllowed = array_map('strtoupper', (array)$allowedRoles);
    if (!in_array($role, $normalizedAllowed)) {
        json_out([
            "success" => false,
            "error" => "Access denied: Your account role ($role) does not have permission for this operation.",
            "code" => "FORBIDDEN"
        ], 403);
    }
    return $user;
}
?>
